package cn.enilu.flash.dao.shop;


import cn.enilu.flash.bean.entity.shop.Category;
import cn.enilu.flash.dao.BaseRepository;


public interface CategoryRepository extends BaseRepository<Category,Long>{

}

