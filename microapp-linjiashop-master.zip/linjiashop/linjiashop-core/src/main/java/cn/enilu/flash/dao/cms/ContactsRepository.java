package cn.enilu.flash.dao.cms;

import cn.enilu.flash.bean.entity.cms.Contacts;
import cn.enilu.flash.dao.BaseRepository;

public interface ContactsRepository extends BaseRepository<Contacts,Long> {
}
