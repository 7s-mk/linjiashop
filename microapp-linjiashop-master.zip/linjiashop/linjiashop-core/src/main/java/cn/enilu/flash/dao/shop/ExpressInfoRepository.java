package cn.enilu.flash.dao.shop;


import cn.enilu.flash.bean.entity.shop.ExpressInfo;
import cn.enilu.flash.dao.BaseRepository;


public interface ExpressInfoRepository extends BaseRepository<ExpressInfo,Long>{

}

